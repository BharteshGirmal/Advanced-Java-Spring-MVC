package DBConnection.InSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseInSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseInSpringApplication.class, args);
	}

}
