package DBConnection.InSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseInSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
