package Beans;

public class PersonBean 
{
	private String name;
	private int age;
	private AddressBean reciveAddress;

	public AddressBean getReciveAddress()
	{
		return reciveAddress;
	}

	public void setReciveAddress(AddressBean reciveAddress) {
		this.reciveAddress = reciveAddress;
	}

	public PersonBean()
	{
		System.out.println("PersonBean Constructor Called");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
